<div align="center">

# [DISCLAIMER]
PROGRAM CREATED FOR EDUCATIONAL PURPOSES ONLY! THE AUTHOR IS NOT RESPONSIBLE FOR THE USE OF THIS SOFTWARE!

# [INFO]
Hello! This repository is a modified version of the "44CALIBER" stealer... In this modified version, I fixed some issues with the original stealer...

Changes:

Fixed IP retrieval,
Added autostart (if you don't want to use it, delete all lines from 22 to 28 in Program.cs)

To receive logs, you need to go to "Resources/Discord/DiscordWebhook.cs", then create a server on Discord, create a webhook, copy its URL, and paste it into the "defaultWebhook" field. In the "defaultUserAgent" field, you can enter any name, the same goes for "defaultUserName". Do not touch "defaultAvatar" (I don't know how to use it myself lol).

Log format:

![Image alt](https://github.com/dxeglow/44CALIBER-MODIFED/blob/main/log.png)

# [CREDITS]
[Original repository link](https://github.com/razexgod/44CALIBER)
